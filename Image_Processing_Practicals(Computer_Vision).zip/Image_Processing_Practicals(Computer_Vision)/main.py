
# ============================================================
# IMAGE PREPROCESSING PRACTICAL
# ============================================================

# 1. IMPORT LIBRARIES

import cv2
import numpy as np
import matplotlib.pyplot as plt
import os


# ============================================================
# 2. FUNCTION TO DISPLAY TWO IMAGES
# ============================================================

def show_images(img1, img2, title1="Original",
                title2="Processed", cmap1=None, cmap2=None):

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    axes[0].imshow(img1, cmap=cmap1)
    axes[0].set_title(title1)
    axes[0].axis("off")

    axes[1].imshow(img2, cmap=cmap2)
    axes[1].set_title(title2)
    axes[1].axis("off")

    plt.tight_layout()
    plt.show()
    plt.close()


# ============================================================
# 3. FIND ORIGINAL IMAGES
# ============================================================

project_folder = os.path.dirname(os.path.abspath(__file__))

output_folder = os.path.join(project_folder, "output")

os.makedirs(output_folder, exist_ok=True)

image_paths = []

# Search the project folder and its subfolders
for root, dirs, files in os.walk(project_folder):

    # Ignore output and other non-input folders
    dirs[:] = [
        folder for folder in dirs
        if folder.lower() not in (
            "output", ".venv", "venv", "__pycache__",
            ".git", "screenshots"
        )
    ]

    for filename in sorted(files):

        if filename.lower().endswith(
            (".jpg", ".jpeg", ".png", ".bmp")
        ):

            image_paths.append(
                os.path.join(root, filename)
            )


# Display discovered images
print("\n================================")
print("IMAGE DISCOVERY")
print("================================")

print("Images found:", len(image_paths))

for path in image_paths:
    print("Found:", path)

if len(image_paths) == 0:
    raise FileNotFoundError(
        "No images found. Put your original photographs "
        "inside the project folder."
    )

if len(image_paths) < 2:
    print(
        "\nWARNING: Only one image was found. "
        "Add your second original image to complete the assignment."
    )


# ============================================================
# 4. PROCESS EACH IMAGE
# ============================================================

successful_images = 0

for number, image_path in enumerate(image_paths, start=1):

    print("\n================================")
    print("PROCESSING IMAGE", number)
    print("Filename:", os.path.basename(image_path))
    print("================================")

    # --------------------------------------------------------
    # A. LOAD AND INSPECT IMAGE
    # --------------------------------------------------------

    image = cv2.imread(image_path)

    if image is None:
        print("Could not read image:", image_path)
        continue

    image_rgb = cv2.cvtColor(
        image, cv2.COLOR_BGR2RGB
    )

    print("Original Dimensions:", image.shape)

    # --------------------------------------------------------
    # B. RESIZE IMAGE
    # --------------------------------------------------------

    resized_image = cv2.resize(
        image_rgb, (256, 256)
    )

    print("Resized Dimensions:", resized_image.shape)

    # --------------------------------------------------------
    # C. IMAGE NORMALIZATION
    # --------------------------------------------------------

    normalized_image = cv2.normalize(
        resized_image,
        None,
        alpha=0,
        beta=1,
        norm_type=cv2.NORM_MINMAX,
        dtype=cv2.CV_32F
    )

    normalized_saved = (
        normalized_image * 255
    ).astype(np.uint8)

    # --------------------------------------------------------
    # D. NOISE REDUCTION
    # --------------------------------------------------------

    gaussian_blur = cv2.GaussianBlur(
        resized_image, (5, 5), 0
    )

    median_blur = cv2.medianBlur(
        resized_image, 5
    )

    # --------------------------------------------------------
    # E. GRAYSCALE CONVERSION
    # --------------------------------------------------------

    gray_image = cv2.cvtColor(
        resized_image, cv2.COLOR_RGB2GRAY
    )

    # --------------------------------------------------------
    # F. IMAGE ENHANCEMENT
    # --------------------------------------------------------

    hist_eq = cv2.equalizeHist(gray_image)

    clahe = cv2.createCLAHE(
        clipLimit=2.0,
        tileGridSize=(8, 8)
    )

    clahe_eq = clahe.apply(gray_image)

    # --------------------------------------------------------
    # G. COLOUR SPACE CONVERSION
    # --------------------------------------------------------

    hsv_image = cv2.cvtColor(
        resized_image, cv2.COLOR_RGB2HSV
    )

    lab_image = cv2.cvtColor(
        resized_image, cv2.COLOR_RGB2LAB
    )

    # --------------------------------------------------------
    # H. IMAGE THRESHOLDING
    # --------------------------------------------------------

    _, binary_thresh = cv2.threshold(
        gray_image,
        127,
        255,
        cv2.THRESH_BINARY
    )

    adaptive_thresh = cv2.adaptiveThreshold(
        gray_image,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        11,
        2
    )

    # --------------------------------------------------------
    # I. CANNY EDGE DETECTION
    # --------------------------------------------------------

    edges = cv2.Canny(
        gray_image, 100, 200
    )

    # --------------------------------------------------------
    # J. MORPHOLOGICAL PROCESSING
    # --------------------------------------------------------

    kernel = np.ones(
        (5, 5), np.uint8
    )

    erosion = cv2.erode(
        binary_thresh,
        kernel,
        iterations=1
    )

    dilation = cv2.dilate(
        binary_thresh,
        kernel,
        iterations=1
    )

    # --------------------------------------------------------
    # K. IMAGE AUGMENTATION
    # --------------------------------------------------------

    flipped_image = cv2.flip(
        resized_image, 1
    )

    rotated_image = cv2.rotate(
        resized_image,
        cv2.ROTATE_90_CLOCKWISE
    )

    # --------------------------------------------------------
    # L. DISPLAY PROCESSING RESULTS
    # --------------------------------------------------------

    show_images(
        resized_image,
        edges,
        f"Image {number} - Resized",
        f"Image {number} - Canny Edges",
        cmap2="gray"
    )

    show_images(
        gray_image,
        clahe_eq,
        f"Image {number} - Grayscale",
        f"Image {number} - CLAHE",
        cmap1="gray",
        cmap2="gray"
    )

    # --------------------------------------------------------
    # M. CREATE SEPARATE OUTPUT FOLDER
    # --------------------------------------------------------

    image_output_folder = os.path.join(
        output_folder,
        f"Image_{number}"
    )

    os.makedirs(
        image_output_folder,
        exist_ok=True
    )

    # --------------------------------------------------------
    # N. SAVE ALL PROCESSED IMAGES
    # --------------------------------------------------------

    # 1. Resized image
    cv2.imwrite(
        os.path.join(image_output_folder, "01_resized.jpg"),
        cv2.cvtColor(resized_image, cv2.COLOR_RGB2BGR)
    )

    # 2. Normalized image
    cv2.imwrite(
        os.path.join(image_output_folder, "02_normalized.jpg"),
        cv2.cvtColor(normalized_saved, cv2.COLOR_RGB2BGR)
    )

    # 3. Gaussian blur
    cv2.imwrite(
        os.path.join(image_output_folder, "03_gaussian.jpg"),
        cv2.cvtColor(gaussian_blur, cv2.COLOR_RGB2BGR)
    )

    # 4. Median blur
    cv2.imwrite(
        os.path.join(image_output_folder, "04_median.jpg"),
        cv2.cvtColor(median_blur, cv2.COLOR_RGB2BGR)
    )

    # 5. Grayscale
    cv2.imwrite(
        os.path.join(image_output_folder, "05_grayscale.jpg"),
        gray_image
    )

    # 6. Histogram equalization
    cv2.imwrite(
        os.path.join(image_output_folder, "06_histogram.jpg"),
        hist_eq
    )

    # 7. CLAHE
    cv2.imwrite(
        os.path.join(image_output_folder, "07_CLAHE.jpg"),
        clahe_eq
    )

    # 8. HSV
    cv2.imwrite(
        os.path.join(image_output_folder, "08_HSV.png"),
        hsv_image
    )

    # 9. LAB
    cv2.imwrite(
        os.path.join(image_output_folder, "09_LAB.png"),
        lab_image
    )

    # 10. Binary threshold
    cv2.imwrite(
        os.path.join(image_output_folder, "10_binary.jpg"),
        binary_thresh
    )

    # 11. Adaptive threshold
    cv2.imwrite(
        os.path.join(image_output_folder, "11_adaptive.jpg"),
        adaptive_thresh
    )

    # 12. Canny edges
    cv2.imwrite(
        os.path.join(image_output_folder, "12_edges.jpg"),
        edges
    )

    # 13. Erosion
    cv2.imwrite(
        os.path.join(image_output_folder, "13_erosion.jpg"),
        erosion
    )

    # 14. Dilation
    cv2.imwrite(
        os.path.join(image_output_folder, "14_dilation.jpg"),
        dilation
    )

    # 15. Horizontal flip
    cv2.imwrite(
        os.path.join(image_output_folder, "15_flip.jpg"),
        cv2.cvtColor(flipped_image, cv2.COLOR_RGB2BGR)
    )

    # 16. Rotation
    cv2.imwrite(
        os.path.join(image_output_folder, "16_rotation.jpg"),
        cv2.cvtColor(rotated_image, cv2.COLOR_RGB2BGR)
    )

    # --------------------------------------------------------
    # O. CONFIRM IMAGE PROCESSING
    # --------------------------------------------------------

    successful_images += 1

    print("\nImage", number, "processed successfully!")
    print("Results saved in:", image_output_folder)


# ============================================================
# 5. FINAL EXECUTION SUMMARY
# ============================================================

print("\n========================================")
print("IMAGE PREPROCESSING COMPLETED!")
print("========================================")

print("Images successfully processed:", successful_images)
print("Total images discovered:", len(image_paths))
print("Results saved inside:", output_folder)

print("========================================")
